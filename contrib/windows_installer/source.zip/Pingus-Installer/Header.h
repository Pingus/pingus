#define WIN32_MEAN_AND_LEAN
#include <windows.h>

const int MyMaxPath = MAX_PATH * 2;
