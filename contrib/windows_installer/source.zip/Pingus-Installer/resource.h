//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Installer.rc
//
#define dlgInstall                      101
#define IDI_ICON1                       103
#define txtEdit                         1000
#define cmdBrowse                       1001
#define chkExecute                      1003
#define chkShortcut                     1004
#define barTop                          1009
#define prgBar                          1012
#define lblWelcome                      1013
#define lblInstallTo                    1014
#define lblInstallFile                  1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
