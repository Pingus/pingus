

bool Exists(char* File);
bool ExistsDir(char* File);
bool CanReadWrite(char* File);
void NormalPath(char* File);
bool CreateFolder(char* File);
