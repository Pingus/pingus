
LPTSTR CopyString(LPCTSTR s);
