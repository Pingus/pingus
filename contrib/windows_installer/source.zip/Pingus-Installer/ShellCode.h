

void ShellInit();
void ShellDest();

bool CreateDesktopShortcut(HWND hDlg, char* Target);
void Browse(HWND hDlg, HWND hText);
void GetProgramFiles(HWND hDlg, char* Buffer);
